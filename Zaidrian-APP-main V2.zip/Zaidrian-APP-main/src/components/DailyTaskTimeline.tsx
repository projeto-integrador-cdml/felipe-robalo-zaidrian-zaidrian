import React from "react";
import TaskItem from "./TaskItem";
import { cn } from "@/lib/utils"; // Import cn utility

interface Task {
  id: string;
  time: string;
  description: string;
  status?: "OK" | "Pending" | "Missed";
  projectColor: string;
  cameraDetect?: boolean;
  blockSocialSites?: boolean;
  date: Date; // Adicionado campo de data
}

interface DailyTaskTimelineProps {
  tasks: Task[];
  onTaskClick: (task: Task) => void;
  onToggleTaskComplete: (taskId: string, isCompleted: boolean) => void; // Nova prop
  className?: string; // Adicionando a prop className
}

const DailyTaskTimeline: React.FC<DailyTaskTimelineProps> = ({ tasks, onTaskClick, onToggleTaskComplete, className }) => {
  return (
    <div className={cn("bg-white p-4 rounded-lg shadow-sm font-sans text-dashboard-text-primary", className)}>
      <h2 className="text-xl font-bold mb-4">Tarefas do Dia</h2>
      <div className="space-y-4">
        {tasks.map((task) => (
          <TaskItem
            key={task.id}
            {...task}
            onTaskClick={() => onTaskClick(task)}
            onToggleComplete={onToggleTaskComplete} // Passando a prop
          />
        ))}
        {tasks.length > 0 && (
          <div className="text-center text-gray-500 text-lg font-semibold">...</div>
        )}
        {tasks.length === 0 && (
          <p className="text-center text-gray-500">Nenhuma tarefa agendada para hoje.</p>
        )}
      </div>
    </div>
  );
};

export default DailyTaskTimeline;