import React from "react";
import { Badge } from "@/components/ui/badge";
import { Camera, Shield } from "lucide-react";
import { cn } from "@/lib/utils";
import { Checkbox } from "@/components/ui/checkbox"; // Importar Checkbox

interface TaskItemProps {
  id: string; // Adicionar id para identificar a tarefa
  time: string;
  description: string;
  status?: "OK" | "Pending" | "Missed";
  projectColor: string; // Tailwind color class for the vertical bar
  cameraDetect?: boolean;
  blockSocialSites?: boolean;
  onTaskClick: () => void;
  onToggleComplete: (taskId: string, isCompleted: boolean) => void; // Nova prop
}

const TaskItem: React.FC<TaskItemProps> = ({
  id,
  time,
  description,
  status,
  projectColor,
  cameraDetect,
  blockSocialSites,
  onTaskClick,
  onToggleComplete,
}) => {
  const isCompleted = status === "OK";
  const statusColor = isCompleted ? "bg-green-500" : status === "Pending" ? "bg-yellow-500" : "bg-gray-400";

  return (
    <div
      className="flex items-start space-x-4 py-2 relative group rounded-md p-2 -mx-2 transition-colors"
    >
      <div className="flex items-center h-full mt-1"> {/* Ajuste para alinhar o checkbox */}
        <Checkbox
          checked={isCompleted}
          onCheckedChange={(checked) => onToggleComplete(id, checked as boolean)}
          className="mr-2"
        />
      </div>
      <div
        className={cn(
          "w-2 h-full min-h-16 rounded-full",
          projectColor,
          isCompleted && "opacity-50" // Diminui a opacidade da barra de cor se concluída
        )}
      ></div>
      <div className="flex-1 flex flex-col cursor-pointer" onClick={onTaskClick}> {/* Torna o restante do item clicável para edição */}
        <div className="flex justify-between items-center">
          <span className={cn("font-semibold text-lg", isCompleted && "line-through text-gray-500")}>
            {time}
          </span>
          {status && (
            <Badge className={cn("rounded-full px-3 py-1 text-xs text-white", statusColor)}>
              {status}
            </Badge>
          )}
        </div>
        <p className={cn("text-gray-700 text-base", isCompleted && "line-through text-gray-500")}>
          {description}
        </p>
        {(cameraDetect || blockSocialSites) && (
          <div className={cn("flex items-center space-x-2 mt-2 text-sm text-gray-500", isCompleted && "opacity-50")}>
            {cameraDetect && (
              <span className="flex items-center space-x-1 bg-gray-200 px-2 py-1 rounded-full">
                <Camera className="h-3 w-3" />
                <span>Camera detect</span>
              </span>
            )}
            {blockSocialSites && (
              <span className="flex items-center space-x-1 bg-gray-200 px-2 py-1 rounded-full">
                <Shield className="h-3 w-3" />
                <span>Block social sites</span>
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default TaskItem;