import React from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";

const formSchema = z.object({
  name: z.string().min(1, "O nome do projeto é obrigatório"),
  color: z.string().min(1, "Selecione uma cor para o projeto"),
});

interface Project {
  id: string;
  name: string;
  totalTime: string;
  color: string;
}

interface EditProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project | null;
  onSave: (projectId: string, updatedProject: z.infer<typeof formSchema>) => void;
  onDelete: (projectId: string) => void;
}

const projectColors = [
  { id: "purple", name: "Roxo", class: "bg-dashboard-project-purple" },
  { id: "green", name: "Verde", class: "bg-dashboard-project-green" },
  { id: "orange", name: "Laranja", class: "bg-dashboard-project-orange" },
  { id: "blue", name: "Azul", class: "bg-dashboard-project-blue" },
  { id: "pink", name: "Rosa", class: "bg-dashboard-project-pink" },
  { id: "teal", name: "Ciano", class: "bg-dashboard-project-teal" },
];

const EditProjectModal: React.FC<EditProjectModalProps> = ({ isOpen, onClose, project, onSave, onDelete }) => {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      color: "",
    },
  });

  React.useEffect(() => {
    if (project) {
      form.reset({
        name: project.name,
        color: project.color,
      });
    }
  }, [project, form]);

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    if (project) {
      onSave(project.id, values);
      onClose();
      toast.success("Projeto atualizado com sucesso!");
    }
  };

  const handleDeleteClick = () => {
    if (project) {
      onDelete(project.id);
      onClose(); // Fecha o modal de edição, o AlertDialog de confirmação será aberto
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-white text-dashboard-text-primary">
        <DialogHeader>
          <DialogTitle>{project ? "Editar Projeto" : "Detalhes do Projeto"}</DialogTitle>
          <DialogDescription>
            {project ? "Ajuste os detalhes do seu projeto ou exclua-o." : "Visualizar detalhes do projeto."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 py-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome do Projeto</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: Projeto de IA" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="color"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cor de Identificação</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma cor" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {projectColors.map((colorOption) => (
                        <SelectItem key={colorOption.id} value={colorOption.class}>
                          <div className="flex items-center">
                            <span className={`w-4 h-4 rounded-full mr-2 ${colorOption.class}`}></span>
                            {colorOption.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter className="flex flex-row justify-between items-center mt-4">
              <Button
                type="button"
                variant="destructive"
                onClick={handleDeleteClick}
                className="flex items-center space-x-2"
              >
                <Trash2 className="h-4 w-4" />
                <span>Excluir Projeto</span>
              </Button>
              <Button type="submit" className="bg-dashboard-highlight-red hover:bg-dashboard-highlight-red/90 text-white">
                Salvar Alterações
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default EditProjectModal;