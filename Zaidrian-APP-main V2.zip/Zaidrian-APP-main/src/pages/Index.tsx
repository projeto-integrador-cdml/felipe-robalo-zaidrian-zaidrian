import React, { useState } from "react";
import { MadeWithDyad } from "@/components/made-with-dyad";
import MonthlyCalendar from "@/components/MonthlyCalendar";
import ProjectSummaryCard from "@/components/ProjectSummaryCard";
import MainClock from "@/components/MainClock";
import ProfileCard from "@/components/ProfileCard";
import AddTaskButton from "@/components/AddTaskButton";
import DailyTaskTimeline from "@/components/DailyTaskTimeline";
import AddTaskModal from "@/components/AddTaskModal";
import CreateProjectModal from "@/components/CreateProjectModal";
import EditTaskModal from "@/components/EditTaskModal";
import EditProjectModal from "@/components/EditProjectModal";
import { format, isSameDay } from "date-fns";
import { ptBR } from "date-fns/locale";
import { z } from "zod";
import { PlusCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

// Define o schema para as tarefas para reutilização
const taskSchema = z.object({
  project: z.string().min(1, "Selecione um projeto"),
  description: z.string().min(1, "A descrição da tarefa é obrigatória"),
  startTime: z.string().min(1, "Horário de início é obrigatório"),
  endTime: z.string().min(1, "Horário de término é obrigatório"),
  date: z.date({
    required_error: "A data da tarefa é obrigatória.",
  }),
  cameraDetect: z.boolean().default(false),
  blockSocialSites: z.boolean().default(false),
});

type Task = z.infer<typeof taskSchema> & { id: string; projectColor: string; status?: "OK" | "Pending" | "Missed" };

interface Project {
  id: string;
  name: string;
  totalTime: string; // Para exibição, ex: "14h"
  color: string; // Classe de cor do Tailwind
}

const Index = () => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [isAddTaskModalOpen, setIsAddTaskModalOpen] = useState(false);
  const [isCreateProjectModalOpen, setIsCreateProjectModalOpen] = useState(false);
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);
  const [projectToEdit, setProjectToEdit] = useState<Project | null>(null);
  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);

  const [projects, setProjects] = useState<Project[]>([
    { id: "llm", name: "Projeto LLM", totalTime: "14h", color: "bg-dashboard-project-purple" },
    { id: "invest", name: "Aprender a investir", totalTime: "9h", color: "bg-dashboard-project-green" },
    { id: "german", name: "Estudar alemão", totalTime: "3h", color: "bg-dashboard-project-orange" },
  ]);

  const [tasks, setTasks] = useState<Task[]>([
    {
      id: "1",
      time: "8h - 10h30m",
      description: "Correção dos embeddings",
      status: "OK",
      project: "llm",
      projectColor: "bg-dashboard-project-purple",
      startTime: "08:00",
      endTime: "10:30",
      date: new Date(), // Tarefa para hoje
    },
    {
      id: "2",
      time: "18h - 19h",
      description: "Revisar documentação",
      status: "Pending",
      project: "invest",
      projectColor: "bg-dashboard-project-green",
      cameraDetect: true,
      blockSocialSites: true,
      startTime: "18:00",
      endTime: "19:00",
      date: new Date(), // Tarefa para hoje
    },
    {
      id: "3",
      time: "14h - 16h",
      description: "Planejar próxima sprint",
      status: "Pending",
      project: "llm",
      projectColor: "bg-dashboard-project-purple",
      startTime: "14:00",
      endTime: "16:00",
      date: new Date(new Date().setDate(new Date().getDate() + 2)), // Tarefa para daqui a 2 dias
    },
  ]);

  const handleCreateProject = (newProjectData: { name: string; color: string }) => {
    const newProject: Project = {
      id: newProjectData.name.toLowerCase().replace(/\s/g, "-") + "-" + Date.now(),
      name: newProjectData.name,
      totalTime: "0h",
      color: newProjectData.color,
    };
    setProjects((prevProjects) => [...prevProjects, newProject]);
  };

  const handleEditProject = (project: Project) => {
    setProjectToEdit(project);
  };

  const handleSaveProject = (projectId: string, updatedProjectData: { name: string; color: string }) => {
    setProjects((prevProjects) =>
      prevProjects.map((p) =>
        p.id === projectId
          ? {
              ...p,
              name: updatedProjectData.name,
              color: updatedProjectData.color,
            }
          : p
      )
    );
    // Atualizar a cor das tarefas associadas a este projeto
    setTasks((prevTasks) =>
      prevTasks.map((t) =>
        t.project === projectId
          ? {
              ...t,
              projectColor: updatedProjectData.color,
            }
          : t
      )
    );
    setProjectToEdit(null);
  };

  const handleDeleteProject = (projectId: string) => {
    const project = projects.find(p => p.id === projectId);
    if (!project) return;
    setProjectToDelete(project);
  };

  const confirmDeleteProject = () => {
    if (projectToDelete) {
      setProjects((prevProjects) => prevProjects.filter((p) => p.id !== projectToDelete.id));
      setTasks((prevTasks) => prevTasks.filter((t) => t.project === projectToDelete.id)); // Remove tarefas do projeto excluído
      toast.success(`Projeto "${projectToDelete.name}" excluído com sucesso!`);
      setProjectToDelete(null);
    }
  };

  const handleAddTask = (newTaskData: z.infer<typeof taskSchema>) => {
    const project = projects.find(p => p.id === newTaskData.project);
    if (project) {
      const newTask: Task = {
        id: String(tasks.length + 1) + "-" + Date.now(),
        time: `${newTaskData.startTime} - ${newTaskData.endTime}`,
        description: newTaskData.description,
        status: "Pending", // Novas tarefas começam como Pendentes
        project: newTaskData.project,
        projectColor: project.color,
        cameraDetect: newTaskData.cameraDetect,
        blockSocialSites: newTaskData.blockSocialSites,
        startTime: newTaskData.startTime,
        endTime: newTaskData.endTime,
        date: newTaskData.date,
      };
      setTasks((prevTasks) => [...prevTasks, newTask]);
    }
  };

  const handleTaskClick = (task: Task) => {
    setTaskToEdit(task);
  };

  const handleSaveTask = (taskId: string, updatedTaskData: z.infer<typeof taskSchema>) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) =>
        task.id === taskId
          ? {
              ...task,
              ...updatedTaskData,
              time: `${updatedTaskData.startTime} - ${updatedTaskData.endTime}`,
              projectColor: projects.find(p => p.id === updatedTaskData.project)?.color || task.projectColor,
            }
          : task
      )
    );
    setTaskToEdit(null);
  };

  const handleDeleteTaskFromModal = (taskId: string) => {
    setTasks((prevTasks) => prevTasks.filter((t) => t.id !== taskId));
    toast.success("Tarefa excluída com sucesso!");
    setTaskToEdit(null);
  };

  const handleToggleTaskComplete = (taskId: string, isCompleted: boolean) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) =>
        task.id === taskId
          ? { ...task, status: isCompleted ? "OK" : "Pending" }
          : task
      )
    );
    toast.success(isCompleted ? "Tarefa marcada como concluída!" : "Tarefa marcada como pendente!");
  };

  const tasksForSelectedDate = tasks.filter(task => isSameDay(task.date, selectedDate));

  // Cálculo da porcentagem de conclusão
  const completedTasksCount = tasksForSelectedDate.filter(task => task.status === "OK").length;
  const totalTasksCount = tasksForSelectedDate.length;
  const completionPercentage = totalTasksCount > 0 ? Math.round((completedTasksCount / totalTasksCount) * 100) : 0;

  return (
    <div className="min-h-screen flex flex-col p-4 bg-dashboard-background font-sans text-dashboard-text-primary">
      {/* Conteúdo principal: duas colunas */}
      <div className="flex flex-col lg:flex-row gap-6 flex-grow">
        {/* Coluna da Esquerda (Visão Geral) */}
        <div className="lg:w-[40%] flex flex-col space-y-6">
          <div className="flex items-center justify-center bg-white p-4 rounded-lg shadow-sm">
            <MainClock progress={30} progressColor="text-dashboard-project-purple" />
          </div>
          <MonthlyCalendar selectedDate={selectedDate} onDateSelect={setSelectedDate} />
          <div className="flex flex-col flex-grow gap-4">
            {projects.map((project) => (
              <ProjectSummaryCard
                key={project.id}
                projectName={project.name}
                totalTime={project.totalTime}
                color={project.color}
                onDelete={() => handleDeleteProject(project.id)}
                onEdit={() => handleEditProject(project)}
              />
            ))}
            <Button
              onClick={() => setIsCreateProjectModalOpen(true)}
              className="w-full bg-gray-200 text-gray-700 hover:bg-gray-300 flex items-center justify-center space-x-2 py-6 rounded-lg shadow-sm mt-auto"
            >
              <PlusCircle className="h-5 w-5" />
              <span>Criar Novo Projeto</span>
            </Button>
          </div>
        </div>

        {/* Coluna da Direita (Ação Diária) */}
        <div className="lg:w-[60%] flex flex-col space-y-6">
          <div className="flex items-center justify-between bg-white p-4 rounded-lg shadow-sm relative">
            <div className="relative flex items-center">
              <img src="/gopher-logo.png" alt="Gopher Logo" className="h-20 w-auto" />
              {completedTasksCount > 0 && (
                <div className="absolute left-24 top-1/2 -translate-y-1/2 bg-dashboard-highlight-red text-white text-xs font-bold px-3 py-1 rounded-full shadow-md whitespace-nowrap
                                  before:content-[''] before:absolute before:top-1/2 before:-translate-y-1/2 before:left-0 before:-translate-x-[50%] before:border-8 before:border-r-dashboard-highlight-red before:border-t-transparent before:border-b-transparent before:border-l-transparent">
                  {completionPercentage}% concluído!
                </div>
              )}
            </div>
            <div className="flex flex-col items-end space-y-2">
              <span className="text-lg font-semibold capitalize">
                {format(selectedDate, "d MMMM, yyyy", { locale: ptBR })}
              </span>
              <div className="flex space-x-4">
                <ProfileCard />
                <AddTaskButton onClick={() => setIsAddTaskModalOpen(true)} />
              </div>
            </div>
          </div>
          <DailyTaskTimeline
            tasks={tasksForSelectedDate}
            onTaskClick={handleTaskClick}
            onToggleTaskComplete={handleToggleTaskComplete}
            className="flex-grow"
          />
        </div>
      </div>

      <AddTaskModal
        isOpen={isAddTaskModalOpen}
        onClose={() => setIsAddTaskModalOpen(false)}
        onAddTask={handleAddTask}
        projects={projects}
        initialDate={selectedDate}
      />
      <CreateProjectModal
        isOpen={isCreateProjectModalOpen}
        onClose={() => setIsCreateProjectModalOpen(false)}
        onCreateProject={handleCreateProject}
      />

      <EditProjectModal
        isOpen={!!projectToEdit}
        onClose={() => setProjectToEdit(null)}
        project={projectToEdit}
        onSave={handleSaveProject}
        onDelete={handleDeleteProject}
      />

      <EditTaskModal
        isOpen={!!taskToEdit}
        onClose={() => setTaskToEdit(null)}
        task={taskToEdit}
        projects={projects}
        onSave={handleSaveTask}
        onDelete={handleDeleteTaskFromModal}
      />

      <AlertDialog open={!!projectToDelete} onOpenChange={() => setProjectToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão de Projeto</AlertDialogTitle>
            <AlertDialogDescription>
              Você tem certeza que deseja excluir o projeto "
              {projectToDelete?.name}"? Todas as tarefas e o tempo registrado serão perdidos permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteProject} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Confirmar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <MadeWithDyad />
    </div>
  );
};

export default Index;